# Institute of Helical Research webpage

## Setup:
The setup required for this application requires only opening the index.html file in a browser of your choice.

---
## Technologies:
This application ws created using HTML, CSS, and javascript.

---

## User Experience:
After loading the index page the user is invited to explore different links to courses offered by the company the website was designed for (Institute of 
Helical research).  Also the user has the option of navigation buttons in the footer of the index page.  After a course link is pressed the user will be taken to the corresponding page there are three course offferings pages with three courses on each page.  When a course page loads the user is invited to click on one of three buttons that will open a card displaying two images relative to the subject and a short description of the field of study.  The user also has the choice of links in the footer.  If on any page the user selects the about us link they will be taken to the About Us page where they are presented several cards contining carousels with images and adjacent text with answers to FAQ.  The user can choose links form the footer.  If the user clicks on the cost and pricing link on any page they will be taken to the Cost and Pricing page where the user is presented with a panel of buttons that are clickable and open modals corresponding to the button subjects.  The user is also presented with two areas where if moused over expand to reveal information on student loans and scholarship oppurtunities.  On the Contact Us page the user is presented a clickable button inviting them to submit their information through a form that stores the information in the local storage.

---
## Design:
The design of the website was done using the following 9 colors:
#ffff00 Yellow,
#0000ff Blue,
#000 Black,
#00008b Darkblue,
#fff White,
#ff0000 Red,
#808080 Gary,
#ffc0cb Pink,
and 
#ffdead Navajo White. The colors were chosen for their soft pastel tones that are not difficult to focus on but direct the users attention to certain parts of each page for marketing purposes.  Pink is considered a "friendly" color and that is attractive to any business as friendliness is a key to success.  The use of gradients were used to create a theme of oddity which is inline with the sites content offerings and again the bright pastels were used because it makes the animation have more depth and life.

---
## Javascript tools used:
1. for each loop used on  line 11 of pricing.js 
2. A constructor was used on line 43 of the pricing.js
3. Array.from() was used on line 3 of pricing.js
4. .splice() was used on line 10 of pricing.js 
5. addEventListener used throughout pricing.js 

---
## Bootstrap tools used
1. Container 
2. d-flex
3. rows 
4. columns
5. mt and mb 
6. carousel
7. card
8. text center
Bootstrap is used throughout all the html in this project 

---

## Author:
Justin Breazeale is a Front-end development student in The Last Mile.